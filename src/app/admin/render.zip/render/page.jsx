import React from "react";

function page() {
  return (
    <div className="bg-gray-100 lg:ml-12 lg:mr-12">
      <section className="bg-gray-100">
        <div className="grid grid-cols-3 md:grid-cols-3 ">
          <div>
            <img
              className="h-full max-w-full rounded-l-lg"
              src="/hotel_1.jpg"
              alt=""
            />
          </div>
          <div>
            <img className="h-full max-w-full" src="/hotel_2.jpg" alt="" />
          </div>
          <div>
            <img
              className="h-full max-w-full rounded-r-lg"
              src="/hotel_3.jpg"
              alt=""
            />
          </div>
        </div>
      </section>
      <section className="bg-gray-100 mt-8 p-4 lg:p-0">
        <div className="grid grid-cols-3 md:grid-cols-3 ">
          <div className="col-span-2">
            <h1 className="font-bold text-2xl font-playfair text-gray-800">
              John D. Private Room in a house in Greenwich, London
            </h1>
            <div className="grid grid-cols-6 mt-4 gap-24 lg:gap-16">
              <div>
                <p className="font-semibold text-md font-playfair text-gray-800">
                  Rent
                </p>
                <p className="font-semibold text-md font-playfair text-gray-800">
                  Deposit
                </p>
                <p className="font-semibold text-md font-playfair text-gray-800">
                  Available
                </p>
                <p className="font-semibold text-md font-playfair text-gray-800">
                  Type
                </p>
                <p className="font-semibold text-md font-playfair text-gray-800">
                  Layout
                </p>
              </div>
              <div className="lg:col-span-2 col-span-5 ">
                <p className="font-medium text-md font-playfair text-gray-800">
                  $3500 / mo
                </p>
                <p className="font-medium text-md font-playfair text-gray-800">
                  $3500 / mo
                </p>
                <p className="font-medium text-md font-playfair text-gray-800">
                  Dec 3rd, 2024 - Flexible
                </p>
                <p className="font-medium text-md font-playfair text-gray-800">
                  Private room - Co-living - House
                </p>
                <p className="font-medium text-md font-playfair text-gray-800">
                  3 Bedrooms - 2 Bathrooms
                </p>
              </div>
            </div>
          </div>
          <div>
            <div>
              {/* space to place the image if required*/}
              <img
                class="rounded-full w-40 h-40 lg:ml-32 ml-1 mt-4"
                src="/hotel_2.jpg"
                alt="image description"
              />
            </div>
          </div>
        </div>
      </section>
      <section className="mt-8 ">
        <div className="grid-rows-2">
          <div className="grid-rows-1 ">
            <div className="lg:ml-6 pl-6 pr-6">
              <button className="rounded-md bg-blue-950 text-white lg:px-10 py-[10px] px-8">
                Message
              </button>
              <button className="rounded-md bg-blue-800 text-white lg:px-10 py-[10px] px-10 ml-4">
                Apply
              </button>
              <button className="rounded-full bg-blue-950 text-white lg:md:px-6 py-[10px] px-4 lg:ml-16 ml-8">
                Save
              </button>
            </div>
          </div>
          <div>
            {/* space to place the third button if required*/}
            <button></button>
          </div>
        </div>
      </section>
      <section className="bg-gray-100 p-4 lg:p-0">
        <div className="grid grid-cols-8 md:grid-cols-8">
          <div className="lg:col-span-6 pt-2 col-span-7">
            <div className="grid grid-cols-9">
              <div className="lg:col-span-1 col-span-2">
                {/* space to place the image if required*/}
                <img
                  className="w-16 h-16 max-w-full rounded-full"
                  src="/hotel_3.jpg"
                  alt=""
                />
              </div>
              <div className="lg:col-span-8 col-span-7 border-t-[0.5px] border-gray-500">
                <div className="mt-4 text-gray-700 mb-4">
                  Our choice of books reflects our personality and our
                  intellect. Books tell us about new things and enrich our
                  knowledge. They open the doors to a beautiful world and
                  quicken our imagination. They give us company and drive away
                  our boredom. They are friends to the ones who are lonely. They
                  also act as companions to the deserted. They brighten our
                  lives by giving joy to the ones who are joyless and give
                  happiness and pleasure. Books are our true friends because
                  they make us better, wiser and happier.
                </div>
                <div className="border-t-[0.5px] border-gray-500 ">
                  <div>
                    <h2 className="mt-8 font-bold text-gray-800 mr-2">
                      AMENITIES IN THE HOME
                    </h2>
                    <div className="grid lg:grid-cols-3 sm:md:grid-rows-2 pt-4 lg:gap-8 gap-4 lg:pl-4 lg:pr-12">
                      <div className="px-1 py-4 bg-gray-200 rounded-md"></div>
                      <div className="px-1 py-4 bg-gray-200 rounded-md"></div>
                      <div className="px-1 py-4 bg-gray-200 rounded-md"></div>
                      <div className="px-1 py-4 bg-gray-200 rounded-md"></div>
                    </div>
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-800 mr-2 mt-4">
                      ON THE PROPERTY
                    </h2>
                    <div className="grid lg:grid-cols-3 pt-4 lg:gap-8 gap-4 lg:pl-4 lg:pr-12">
                      <div className="px-1 py-4 bg-purple-100 rounded-md"></div>
                      <div className="px-1 py-4 bg-purple-100 rounded-md"></div>
                      <div className="px-1 py-4 bg-purple-100 rounded-md"></div>
                    </div>
                  </div>
                  <div className="mb-4">
                    <h2 className="font-bold text-gray-800 mr-2 mt-4">
                      SAFETY
                    </h2>
                    <div className="grid lg:grid-cols-3 grid-cols-1 pt-4 lg:gap-8 gap-4 lg:pl-4 lg:pr-12">
                      <div className="px-1 py-4 bg-orange-100 rounded-md"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default page;
